function createClothoUser(){
	var username = "user1";
	var password = "password";
	$('#description_field').text('Creating user with username: ' + username);
	Clotho.createUser(username, password).then(function(result){
		console.log(result);
		if (result != null){
       $('#error_field').text('User is Created! Welcome, '+username+'. Please try logging in now!');
     }
     else{
       $('#error_field').text('Cannot create user');
     }

	});
}

function loginUser(){
	var username = "user1";
	var password = "password";
	$('#description_field').text('Logging in user with username: ' + username);
	Clotho.login(username, password).then(function(result){
		console.log(result);
		if (result != null){
        $('#error_field').text('Logged in! Welcome, '+username);
      }
      else{
        $('#error_field').text('Cannot log in');
      }

	});
}

function logoutUser(){
 	$('#description_field').text('Logging out user');
	Clotho.logout().then(function(result){
		console.log(result);
		$('#error_field').text('User is logged out!');
	});
}
