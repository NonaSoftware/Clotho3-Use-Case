function createObject(){
  var obj = {"name":"example_1", "id":"1", "sequence":"cacagatgacgt"};
  $('#description_field').text("Creating Object: "+JSON.stringify(obj));
  Clotho.create(obj).then(function(result){
			console.log(result);
      if(result===undefined){
        $('#response_field').text("Object with that id already exists");
      }
      else{
        $('#response_field').text("Created Object with id: "+result);
      }
		});
}

function queryObject(){
  var obj = {"name":"example_1"};
  $('#description_field').text("Querying Object with details: "+JSON.stringify(obj));
  Clotho.query(obj).then(function(result){
			console.log(result);
      $('#response_field').text("Found Object: " + JSON.stringify(result));
    });
}

function setObject(){
  var obj = {"name":"example_1", "id":"1","sequence":"cat"};
  $('#description_field').text("Changing Object's sequence to: "+JSON.stringify(obj));
  Clotho.set(obj).then(function(result){
			console.log(result);
      $('#response_field').text("Object changed");
    });
}

function getObject(){
  var id = "1";
  $('#description_field').text("Getting Object with id: "+id);
  Clotho.get(id).then(function(result){
			console.log(result);
      if(result===undefined){
        $('#response_field').text("Object doesn't exist");
      }
      else{
        $('#response_field').text("Found Object: "+JSON.stringify(result));
      }
    });
}

function destroyObject(){
  var id = "1";
  $('#description_field').text("Destroying Object with id: "+id);
  Clotho.destroy(id).then(function(result){
			console.log(result);
      $('#response_field').text("Destroyed Object with id: "+result);
    });
  }
